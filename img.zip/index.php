  <?php
   $galleryDir = 'gallery/';
   foreach(glob("$galleryDir{*.jpg,*.gif,*.png,*.tif,*.jpeg}", GLOB_BRACE) as $photo)
   {echo "<a  href=\"$photo\">\n" ;echo "<img style=\"padding:7px\" class=\"uk-card uk-card-default uk-card-hover uk-card-body\" src=\"$photo\">"; echo "</a>";}

   $galleryDir1 = 'gallery/';
   foreach(glob("$galleryDir1{*.pdf}", GLOB_BRACE) as $photo)
   {echo "<a  href=\"$photo\">\n" ;echo $photo; echo "</a>";}?>